dht11为树梅派程序，对应的requirements.txt为所需的开发环境
安装 pycharm anaconda  mqttfx mosquitto xhell winscp navicat
1、配置环境 pip install -r  requirements.txt
2、pycharm导入工程
3、在配置环境中执行python manage.py runserver

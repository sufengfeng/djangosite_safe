# Register your models here.
from django.contrib import admin
from djangosite.models import Test

# Register your models here.
admin.site.register(Test)
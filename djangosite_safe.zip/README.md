# djangosite_web
基于django的web服务器，可用于显示波形

dht11为树梅派程序，对应的requirements.txt为所需的开发环境

安装 pycharm anaconda  mqttfx mosquitto xhell winscp navicat

1、配置环境 pip install -r  requirements.txt

2、pycharm导入工程

3、在配置环境中执行python manage.py runserver


提交记录:

1、基于物联网的云平台显示系统

2、增加树莓派端使用文件，包括python文件和C库文件

3、增加说明文件，和python配置文件
